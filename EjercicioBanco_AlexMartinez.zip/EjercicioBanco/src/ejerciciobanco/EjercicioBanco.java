/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciobanco;

/**
 *
 * @author Usuario
 */
public class EjercicioBanco {
    
    
    public static void main(String[] args){
        Menu_Banco banco= new Menu_Banco();
        banco.Calculos();
    }
    
    
}
    

        
    
     



package ejerciciobanco;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Menu_Banco {
    
    public int salir = 0;
    public int mes;
    public int valor;
    public int opcion; //Guardaremos la opcion del usuario
    public double multi = 0.0;
    public double comision;
    public double total;
    
    Scanner sn = new Scanner(System.in);
    Scanner meses = new Scanner(System.in);
    Scanner monto = new Scanner(System.in);
    
    public void Calculos() {
         
      
       while(salir==0){
            
           System.out.println("1. Cuenta de Ahorro");
           System.out.println("2. Cuenta Corriente");
           System.out.println("3. Cuenta a Plazo Fijo 3 Meses");
           System.out.println("4. Salir");
            
           System.out.print("Indique su alternativa : ");
           opcion = sn.nextInt();
           switch (opcion) {
                    case 1:
                        CalculoAhorro();
                        break;
                    case 2:
                        CalculoCorriente();
                        break;
                    case 3:
                        CalculoFijo();
                        break;
                        
                    case 4:
                        salir = 1;
                        break;
                    default:
                        System.out.println("OPCION NO VALIDA, REINTENTE");
                        break;
                
                
                }
       }
    }
    public void CalculoAhorro(){
        multi= 0.01;
        System.out.print("Introduzca monto del ahorro : ");
        valor = monto.nextInt();
        comision = valor*multi;
        total = valor + comision;
        System.out.println("Tu comision sera de "+comision);
        System.out.println("Tu monto final sera de: "+total+"\n");
        
    }
    
    public void CalculoCorriente(){
        multi= 0.005;
        System.out.print("Introduzca monto del ahorro : ");
        valor = monto.nextInt();
        comision = valor*multi;
        total = valor + comision;
        System.out.println("Tu comision sera de "+comision);
        System.out.println("Tu monto final sera de: "+total+"\n");
        
    }
    
    public void CalculoFijo(){
        multi= 0.012;
        System.out.print("Introduzca monto del ahorro : ");
        valor = monto.nextInt();
        System.out.print("Ingrese los meses del ahorro (3 o 6): ");
        mes=meses.nextInt();
        if (mes==3 || mes==6){
            comision = valor*multi*mes;
            total = valor + comision;
            System.out.println("Tu comision sera de "+comision);
            System.out.println("Tu monto final sera de: "+total+"\n");
        }
        else{
            System.out.println("OPCION INCORRECTA");
                
            }
                    
        }
    }

